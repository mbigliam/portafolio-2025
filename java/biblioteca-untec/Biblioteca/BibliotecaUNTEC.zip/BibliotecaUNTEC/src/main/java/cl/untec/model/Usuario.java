package cl.untec.model;

/**
 * Clase modelo (POJO) que representa la entidad Usuario dentro del sistema de
 * la biblioteca. Almacena la información de identificación, los datos de perfil
 * y las credenciales de autenticación (correo electrónico y contraseña)
 * requeridas para el inicio de sesión.
 * 
 * @author UNTEC / Desarrollador
 * @version 1.0
 */
public class Usuario {

	/** Identificador único del usuario en la base de datos. */
	private int id;

	/** Nombre completo del usuario. */
	private String nombre;

	/**
	 * Correo electrónico único utilizado como identificador para la autenticación.
	 */
	private String email;

	/** Contraseña de seguridad de la cuenta del usuario. */
	private String password;

	/**
	 * Obtiene el ID único del usuario.
	 * 
	 * @return Valor entero con el identificador del usuario.
	 */
	public int getId() {
		return id;
	}

	/**
	 * Establece el ID único del usuario.
	 * 
	 * @param id Nuevo identificador numérico.
	 */
	public void setId(int id) {
		this.id = id;
	}

	/**
	 * Obtiene el nombre completo del usuario.
	 * 
	 * @return Cadena ({@link String}) con el nombre.
	 */
	public String getNombre() {
		return nombre;
	}

	/**
	 * Establece el nombre completo del usuario.
	 * 
	 * @param nombre Nuevo nombre para el usuario.
	 */
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	/**
	 * Obtiene el correo electrónico del usuario.
	 * 
	 * @return Cadena ({@link String}) con el correo electrónico.
	 */
	public String getEmail() {
		return email;
	}

	/**
	 * Establece el correo electrónico del usuario.
	 * 
	 * @param email Nueva dirección de correo electrónico.
	 */
	public void setEmail(String email) {
		this.email = email;
	}

	/**
	 * Obtiene la contraseña de acceso del usuario.
	 * 
	 * @return Cadena ({@link String}) con la contraseña.
	 */
	public String getPassword() {
		return password;
	}

	/**
	 * Establece la contraseña de acceso del usuario.
	 * 
	 * @param password Nueva contraseña de seguridad.
	 */
	public void setPassword(String password) {
		this.password = password;
	}
}