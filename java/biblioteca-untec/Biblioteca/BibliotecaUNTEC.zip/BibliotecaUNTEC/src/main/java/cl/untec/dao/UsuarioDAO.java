package cl.untec.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import cl.untec.model.Usuario;

/**
 * Clase Data Access Object (DAO) para la gestión y persistencia de la entidad
 * Usuario. Proporciona métodos para la autenticación de credenciales de inicio
 * de sesión, la obtención del perfil de usuario y las operaciones CRUD
 * completas sobre los registros en la base de datos.
 * 
 * @author UNTEC / Desarrollador
 * @version 1.0
 */
public class UsuarioDAO {

	/**
	 * Valida las credenciales de acceso de un usuario verificando su correo
	 * electrónico y contraseña.
	 * 
	 * @param email    Correo electrónico ingresado por el usuario en el formulario
	 *                 de login.
	 * @param password Contraseña de acceso.
	 * @return Un valor booleano (`true` si las credenciales son correctas y existe
	 *         coincidencia, `false` en caso contrario).
	 */
	public boolean validarLogin(String email, String password) {
		String sql = "SELECT * FROM usuarios WHERE email = ? AND password = ?";
		try (Connection conn = ConexionDB.getInstance().getConnection();
				PreparedStatement ps = conn.prepareStatement(sql)) {
			ps.setString(1, email);
			ps.setString(2, password);
			try (ResultSet rs = ps.executeQuery()) {
				return rs.next();
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return false;
	}

	/**
	 * Consulta y obtiene el nombre completo de un usuario a partir de su dirección
	 * de correo electrónico.
	 * 
	 * @param email Correo electrónico asociado al usuario.
	 * @return Una cadena ({@link String}) con el nombre del usuario, o por defecto
	 *         "Usuario" si no se encuentra coincidencia.
	 */
	public String obtenerNombrePorEmail(String email) {
		String sql = "SELECT nombre FROM usuarios WHERE email = ?";
		try (Connection conn = ConexionDB.getInstance().getConnection();
				PreparedStatement ps = conn.prepareStatement(sql)) {
			ps.setString(1, email);
			try (ResultSet rs = ps.executeQuery()) {
				if (rs.next()) {
					return rs.getString("nombre");
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return "Usuario";
	}

	/**
	 * Obtiene la lista completa de todos los usuarios registrados en el sistema.
	 * 
	 * @return Una lista ({@link List}) de objetos {@link Usuario} con sus datos de
	 *         perfil.
	 */
	public List<Usuario> obtenerUsuarios() {
		List<Usuario> lista = new ArrayList<>();
		String sql = "SELECT * FROM usuarios";
		try (Connection conn = ConexionDB.getInstance().getConnection();
				Statement stmt = conn.createStatement();
				ResultSet rs = stmt.executeQuery(sql)) {
			while (rs.next()) {
				Usuario u = new Usuario();
				u.setId(rs.getInt("id"));
				u.setNombre(rs.getString("nombre"));
				u.setEmail(rs.getString("email"));
				u.setPassword(rs.getString("password"));
				lista.add(u);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return lista;
	}

	/**
	 * Registra un nuevo usuario en la base de datos con sus respectivos datos de
	 * acceso.
	 * 
	 * @param nombre   Nombre completo del usuario.
	 * @param email    Correo electrónico único para el inicio de sesión.
	 * @param password Contraseña de seguridad para la cuenta.
	 */
	public void insertarUsuario(String nombre, String email, String password) {
		String sql = "INSERT INTO usuarios (nombre, email, password) VALUES (?, ?, ?)";
		try (Connection conn = ConexionDB.getInstance().getConnection();
				PreparedStatement ps = conn.prepareStatement(sql)) {
			ps.setString(1, nombre);
			ps.setString(2, email);
			ps.setString(3, password);
			ps.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	/**
	 * Actualiza los datos de perfil y credenciales de un usuario existente.
	 * 
	 * @param id       Identificador único del usuario.
	 * @param nombre   Nuevo nombre completo.
	 * @param email    Nuevo correo electrónico.
	 * @param password Nueva contraseña de acceso.
	 */
	public void actualizarUsuario(int id, String nombre, String email, String password) {
		String sql = "UPDATE usuarios SET nombre = ?, email = ?, password = ? WHERE id = ?";
		try (Connection conn = ConexionDB.getInstance().getConnection();
				PreparedStatement ps = conn.prepareStatement(sql)) {
			ps.setString(1, nombre);
			ps.setString(2, email);
			ps.setString(3, password);
			ps.setInt(4, id);
			ps.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	/**
	 * Elimina de manera permanente un usuario del sistema basándose en su ID único.
	 * 
	 * @param id Identificador numérico del usuario que se desea eliminar.
	 */
	public void eliminarUsuario(int id) {
		String sql = "DELETE FROM usuarios WHERE id = ?";
		try (Connection conn = ConexionDB.getInstance().getConnection();
				PreparedStatement ps = conn.prepareStatement(sql)) {
			ps.setInt(1, id);
			ps.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}