<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Panel - Biblioteca Digital UNTEC</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
</head>
<body class="bg-light">

    <!-- Navbar Superior -->
    <nav class="navbar navbar-dark bg-dark shadow-sm">
        <div class="container">
            <a class="navbar-brand fw-bold" href="login"><i class="bi bi-book-half me-2"></i>Biblioteca UNTEC</a>
            <div class="d-flex align-items-center text-white">
                <span class="me-3 small"><i class="bi bi-person-circle me-1"></i> <c:out value="${usuarioLogueado}"/></span>
                <a href="login?accion=logout" class="btn btn-outline-light btn-sm"><i class="bi bi-box-arrow-right"></i> Salir</a>
            </div>
        </div>
    </nav>

    <div class="container my-5">
        
        <!-- Buscador y Botones de Acción -->
        <div class="row mb-4 align-items-center">
            <div class="col-md-5">
                <form action="login" method="GET" class="input-group shadow-sm">
                    <input type="hidden" name="accion" value="buscar">
                    <input type="text" name="query" class="form-control" placeholder="Buscar libro por título, autor o ISBN..." required>
                    <button class="btn btn-primary" type="submit"><i class="bi bi-search"></i></button>
                    <a href="login" class="btn btn-outline-secondary">Limpiar</a>
                </form>
            </div>
            <div class="col-md-7 text-end">
                <button class="btn btn-success shadow-sm me-1" data-bs-toggle="modal" data-bs-target="#modalLibro">
                    <i class="bi bi-plus-circle me-1"></i> Nuevo Libro
                </button>
                <button class="btn btn-info shadow-sm text-white me-1" data-bs-toggle="modal" data-bs-target="#modalUsuario">
                    <i class="bi bi-person-plus me-1"></i> Nuevo Usuario
                </button>
                <button class="btn btn-warning shadow-sm" data-bs-toggle="modal" data-bs-target="#modalPrestamo">
                    <i class="bi bi-journal-plus me-1"></i> Prestar Libro
                </button>
            </div>
        </div>

        <!-- Tabla de Libros -->
        <div class="card shadow-sm border-0 mb-5 rounded-4">
            <div class="card-body p-4">
                <h4 class="fw-bold mb-3"><i class="bi bi-journal-text text-primary me-2"></i>Catálogo de Libros</h4>
                <div class="table-responsive">
                    <table class="table table-hover align-middle">
                        <thead class="table-dark">
                            <tr>
                                <th>ID</th>
                                <th>Título</th>
                                <th>Autor</th>
                                <th>ISBN</th>
                                <th>Precio</th>
                                <th class="text-center">Estado</th>
                                <th class="text-center">Acciones</th>
                            </tr>
                        </thead>
                        <tbody>
                            <c:forEach var="l" items="${listaLibros}">
                                <tr>
                                    <td><strong>#<c:out value="${l.id}"/></strong></td>
                                    <td><c:out value="${l.titulo}"/></td>
                                    <td class="text-muted"><c:out value="${l.autor}"/></td>
                                    <td><code><c:out value="${l.isbn}"/></code></td>
                                    <td>$<c:out value="${l.precio}"/></td>
                                    <td class="text-center">
                                        <c:choose>
                                            <c:when test="${l.disponible}">
                                                <span class="badge bg-success-subtle text-success border border-success px-2 py-1">
                                                    <i class="bi bi-circle-fill small text-success me-1"></i> Disponible
                                                </span>
                                            </c:when>
                                            <c:otherwise>
                                                <span class="badge bg-secondary-subtle text-secondary border border-secondary px-2 py-1">
                                                    <i class="bi bi-circle-fill small text-secondary me-1"></i> Prestado
                                                </span>
                                            </c:otherwise>
                                        </c:choose>
                                    </td>
                                    <td class="text-center">
                                        <!-- Botón Editar Libro -->
                                        <button class="btn btn-sm btn-outline-warning me-1" title="Editar" data-bs-toggle="modal" data-bs-target="#modalEditarLibro${l.id}">
                                            <i class="bi bi-pencil-square"></i>
                                        </button>
                                        <!-- Botón Eliminar Libro -->
                                        <a href="login?accion=eliminarLibro&id=<c:out value='${l.id}'/>" class="btn btn-sm btn-outline-danger" title="Eliminar" onclick="return confirm('¿Seguro que deseas eliminar este libro?');">
                                            <i class="bi bi-trash"></i>
                                        </a>
                                    </td>
                                </tr>

                                <!-- Modal Editar Libro Individual -->
                                <div class="modal fade" id="modalEditarLibro${l.id}" tabindex="-1" aria-hidden="true">
                                    <div class="modal-dialog">
                                        <div class="modal-content rounded-4 shadow">
                                            <div class="modal-header bg-warning text-dark">
                                                <h5 class="modal-title"><i class="bi bi-pencil-square me-2"></i>Editar Libro #${l.id}</h5>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                            </div>
                                            <form action="login" method="POST">
                                                <input type="hidden" name="accion" value="actualizarLibro">
                                                <input type="hidden" name="id" value="${l.id}">
                                                <div class="modal-body p-4 text-start">
                                                    <div class="mb-3">
                                                        <label class="form-label fw-bold small">Título</label>
                                                        <input type="text" name="titulo" class="form-control" value="${l.titulo}" required>
                                                    </div>
                                                    <div class="mb-3">
                                                        <label class="form-label fw-bold small">Autor</label>
                                                        <input type="text" name="autor" class="form-control" value="${l.autor}" required>
                                                    </div>
                                                    <div class="mb-3">
                                                        <label class="form-label fw-bold small">ISBN</label>
                                                        <input type="text" name="isbn" class="form-control" value="${l.isbn}" required>
                                                    </div>
                                                    <div class="mb-3">
                                                        <label class="form-label fw-bold small">Precio Referencial ($)</label>
                                                        <input type="number" step="0.01" name="precio" class="form-control" value="${l.precio}" required>
                                                    </div>
                                                </div>
                                                <div class="modal-footer bg-light">
                                                    <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">Cancelar</button>
                                                    <button type="submit" class="btn btn-warning btn-sm fw-bold">Actualizar Cambios</button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </c:forEach>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <!-- Tabla de Usuarios -->
        <div class="card shadow-sm border-0 mb-5 rounded-4">
            <div class="card-body p-4">
                <h4 class="fw-bold mb-3"><i class="bi bi-people text-info me-2"></i>Usuarios Registrados</h4>
                <div class="table-responsive">
                    <table class="table table-hover align-middle">
                        <thead class="table-secondary">
                            <tr>
                                <th>ID</th>
                                <th>Nombre</th>
                                <th>Correo Electrónico</th>
                                <th class="text-center">Acciones</th>
                            </tr>
                        </thead>
                        <tbody>
                            <c:forEach var="u" items="${listaUsuarios}">
                                <tr>
                                    <td><strong>#<c:out value="${u.id}"/></strong></td>
                                    <td><c:out value="${u.nombre}"/></td>
                                    <td class="text-muted"><c:out value="${u.email}"/></td>
                                    <td class="text-center">
                                        <!-- Botón Editar Usuario -->
                                        <button class="btn btn-sm btn-outline-warning me-1" title="Editar Usuario" data-bs-toggle="modal" data-bs-target="#modalEditarUsuario${u.id}">
                                            <i class="bi bi-pencil-square"></i>
                                        </button>
                                        <!-- Botón Eliminar Usuario -->
                                        <a href="login?accion=eliminarUsuario&id=<c:out value='${u.id}'/>" class="btn btn-sm btn-outline-danger" title="Eliminar Usuario" onclick="return confirm('¿Seguro que deseas eliminar este usuario?');">
                                            <i class="bi bi-trash"></i>
                                        </a>
                                    </td>
                                </tr>

                                <!-- Modal Editar Usuario Individual -->
                                <div class="modal fade" id="modalEditarUsuario${u.id}" tabindex="-1" aria-hidden="true">
                                    <div class="modal-dialog">
                                        <div class="modal-content rounded-4 shadow">
                                            <div class="modal-header bg-info text-white">
                                                <h5 class="modal-title"><i class="bi bi-pencil-square me-2"></i>Editar Usuario #${u.id}</h5>
                                                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                                            </div>
                                            <form action="login" method="POST">
                                                <input type="hidden" name="accion" value="actualizarUsuario">
                                                <input type="hidden" name="id" value="${u.id}">
                                                <div class="modal-body p-4 text-start">
                                                    <div class="mb-3">
                                                        <label class="form-label fw-bold small">Nombre Completo</label>
                                                        <input type="text" name="nombre" class="form-control" value="${u.nombre}" required>
                                                    </div>
                                                    <div class="mb-3">
                                                        <label class="form-label fw-bold small">Correo Electrónico</label>
                                                        <input type="email" name="email" class="form-control" value="${u.email}" required>
                                                    </div>
                                                    <div class="mb-3">
                                                        <label class="form-label fw-bold small">Contraseña</label>
                                                        <input type="text" name="password" class="form-control" value="${u.password}" required>
                                                    </div>
                                                </div>
                                                <div class="modal-footer bg-light">
                                                    <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">Cancelar</button>
                                                    <button type="submit" class="btn.btn-info btn-sm fw-bold text-white">Actualizar Usuario</button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </c:forEach>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <!-- Préstamos Activos -->
        <div class="card shadow-sm border-0 mb-4 rounded-4">
            <div class="card-body p-4">
                <h4 class="fw-bold mb-3"><i class="bi bi-clock-history text-warning me-2"></i>Préstamos Activos (Vigentes)</h4>
                <div class="table-responsive">
                    <table class="table table-hover align-middle">
                        <thead class="table-dark">
                            <tr>
                                <th>ID</th>
                                <th>Libro</th>
                                <th>Usuario</th>
                                <th>F. Préstamo</th>
                                <th>F. Límite (14 días)</th>
                                <th>Estado</th>
                                <th class="text-center">Acción</th>
                            </tr>
                        </thead>
                        <tbody>
                            <c:set var="hayActivos" value="false"/>
                            <c:forEach var="p" items="${listaPrestamos}">
                                <c:if test="${!p.devuelto}">
                                    <c:set var="hayActivos" value="true"/>
                                    <tr>
                                        <td><strong>#<c:out value="${p.id}"/></strong></td>
                                        <td><c:out value="${p.tituloLibro}"/></td>
                                        <td><c:out value="${p.nombreUsuario}"/></td>
                                        <td class="text-muted"><c:out value="${p.fechaPrestamo}"/></td>
                                        <td class="text-muted"><c:out value="${p.fechaDevolucionEsperada}"/></td>
                                        <td><span class="badge bg-warning text-dark">En Préstamo</span></td>
                                        <td class="text-center">
                                            <a href="login?accion=devolver&id=<c:out value='${p.id}'/>" class="btn btn-outline-success btn-sm" title="Devolver libro">
                                                <i class="bi bi-arrow-counterclockwise"></i> Devolver
                                            </a>
                                        </td>
                                    </tr>
                                </c:if>
                            </c:forEach>
                            <c:if test="${!hayActivos}">
                                <tr>
                                    <td colspan="7" class="text-center text-muted py-3">No hay préstamos activos en este momento.</td>
                                </tr>
                            </c:if>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <!-- Historial de Devoluciones -->
        <div class="card shadow-sm border-0 rounded-4">
            <div class="card-body p-4">
                <h4 class="fw-bold mb-3"><i class="bi bi-journal-check text-success me-2"></i>Historial de Devoluciones</h4>
                <div class="table-responsive">
                    <table class="table table-hover align-middle">
                        <thead class="table-secondary">
                            <tr>
                                <th>ID</th>
                                <th>Libro</th>
                                <th>Usuario</th>
                                <th>F. Préstamo</th>
                                <th>F. Límite</th>
                                <th>Estado / Multa</th>
                            </tr>
                        </thead>
                        <tbody>
                            <c:set var="hayHistorial" value="false"/>
                            <c:forEach var="p" items="${listaPrestamos}">
                                <c:if test="${p.devuelto}">
                                    <c:set var="hayHistorial" value="true"/>
                                    <tr>
                                        <td><strong>#<c:out value="${p.id}"/></strong></td>
                                        <td><c:out value="${p.tituloLibro}"/></td>
                                        <td><c:out value="${p.nombreUsuario}"/></td>
                                        <td class="text-muted"><c:out value="${p.fechaPrestamo}"/></td>
                                        <td class="text-muted"><c:out value="${p.fechaDevolucionEsperada}"/></td>
                                        <td>
                                            <span class="badge bg-success">Devuelto</span>
                                            <c:if test="${p.multa > 0}">
                                                <span class="badge bg-danger ms-1">Multa: $<c:out value="${p.multa}"/></span>
                                            </c:if>
                                        </td>
                                    </tr>
                                </c:if>
                            </c:forEach>
                            <c:if test="${!hayHistorial}">
                                <tr>
                                    <td colspan="6" class="text-center text-muted py-3">Aún no hay registros en el historial.</td>
                                </tr>
                            </c:if>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

    </div>

    <!-- Modal Nuevo Libro -->
    <div class="modal fade" id="modalLibro" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content rounded-4 shadow">
                <div class="modal-header bg-dark text-white">
                    <h5 class="modal-title"><i class="bi bi-plus-circle me-2"></i>Registrar Nuevo Libro</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form action="login" method="POST">
                    <input type="hidden" name="accion" value="crearLibro">
                    <div class="modal-body p-4">
                        <div class="mb-3">
                            <label class="form-label fw-bold small">Título</label>
                            <input type="text" name="titulo" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label fw-bold small">Autor</label>
                            <input type="text" name="autor" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label fw-bold small">ISBN</label>
                            <input type="text" name="isbn" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label fw-bold small">Precio Referencial ($)</label>
                            <input type="number" step="0.01" name="precio" class="form-control" value="15000" required>
                        </div>
                    </div>
                    <div class="modal-footer bg-light">
                        <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">Cancelar</button>
                        <button type="submit" class="btn btn-primary btn-sm">Guardar</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Modal Nuevo Usuario -->
    <div class="modal fade" id="modalUsuario" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content rounded-4 shadow">
                <div class="modal-header bg-info text-white">
                    <h5 class="modal-title"><i class="bi bi-person-plus me-2"></i>Registrar Nuevo Usuario</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form action="login" method="POST">
                    <input type="hidden" name="accion" value="crearUsuario">
                    <div class="modal-body p-4">
                        <div class="mb-3">
                            <label class="form-label fw-bold small">Nombre Completo</label>
                            <input type="text" name="nombre" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label fw-bold small">Correo Electrónico</label>
                            <input type="email" name="email" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label fw-bold small">Contraseña</label>
                            <input type="password" name="password" class="form-control" required>
                        </div>
                    </div>
                    <div class="modal-footer bg-light">
                        <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">Cancelar</button>
                        <button type="submit" class="btn btn-info text-white btn-sm">Guardar Usuario</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Modal Nuevo Préstamo -->
    <div class="modal fade" id="modalPrestamo" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content rounded-4 shadow">
                <div class="modal-header bg-warning text-dark">
                    <h5 class="modal-title"><i class="bi bi-journal-plus me-2"></i>Registrar Nuevo Préstamo</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form action="login" method="POST">
                    <input type="hidden" name="accion" value="crearPrestamo">
                    <div class="modal-body p-4">
                        <div class="mb-3">
                            <label class="form-label fw-bold small">Seleccionar Libro Disponible</label>
                            <select name="libroId" class="form-select" required>
                                <option value="">-- Elige un libro --</option>
                                <c:forEach var="l" items="${listaLibros}">
                                    <c:if test="${l.disponible}">
                                        <option value="${l.id}"><c:out value="${l.titulo}"/> (<c:out value="${l.autor}"/>)</option>
                                    </c:if>
                                </c:forEach>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label class="form-label fw-bold small">Seleccionar Usuario</label>
                            <select name="usuarioId" class="form-select" required>
                                <option value="">-- Elige un usuario --</option>
                                <c:forEach var="u" items="${listaUsuarios}">
                                    <option value="${u.id}"><c:out value="${u.nombre}"/> (<c:out value="${u.email}"/>)</option>
                                </c:forEach>
                            </select>
                        </div>
                        <div class="form-text text-muted small"><i class="bi bi-info-circle me-1"></i>El préstamo se emitirá por un plazo automático de 14 días.</div>
                    </div>
                    <div class="modal-footer bg-light">
                        <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">Cancelar</button>
                        <button type="submit" class="btn btn-success btn-sm">Generar Préstamo</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>