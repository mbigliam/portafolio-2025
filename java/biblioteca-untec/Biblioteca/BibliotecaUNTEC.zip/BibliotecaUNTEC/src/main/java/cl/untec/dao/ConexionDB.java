package cl.untec.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * Clase de gestión de conexión a la base de datos MySQL implementando el patrón
 * Singleton. Garantiza que exista una única instancia de conexión compartida en
 * toda la aplicación para optimizar los recursos del sistema.
 * 
 * @author UNTEC / Desarrollador
 * @version 1.0
 */
public class ConexionDB {

	/** Instancia única de la clase ConexionDB (Patrón Singleton). */
	private static ConexionDB instancia;

	/** Objeto Connection de JDBC para la manipulación de la base de datos. */
	private Connection conn;

	/** URL de conexión JDBC hacia la base de datos MySQL local de la biblioteca. */
	private String url = "jdbc:mysql://localhost:3306/biblioteca_untec?useSSL=false&serverTimezone=UTC";

	/** Usuario administrador configurado en el servidor MySQL. */
	private String user = "root";

	/** Contraseña de acceso al servidor MySQL. */
	private String password = "Maloso20";

	/**
	 * Constructor privado para evitar la instanciación directa externa (Patrón
	 * Singleton). Carga el Driver de MySQL y establece la primera conexión activa.
	 */
	private ConexionDB() {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			this.conn = DriverManager.getConnection(url, user, password);
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}
	}

	/**
	 * Método de acceso global sincronizado para obtener la única instancia de la
	 * clase ConexionDB.
	 * 
	 * @return Instancia única de ConexionDB.
	 */
	public static synchronized ConexionDB getInstance() {
		if (instancia == null) {
			instancia = new ConexionDB();
		}
		return instancia;
	}

	/**
	 * Obtiene la conexión activa a la base de datos, verificando y reconectando
	 * automáticamente en caso de que la conexión previa se encuentre cerrada o
	 * nula.
	 * 
	 * @return Objeto Connection activo listo para ejecutar consultas SQL.
	 */
	public Connection getConnection() {
		try {
			if (conn == null || conn.isClosed()) {
				conn = DriverManager.getConnection(url, user, password);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return conn;
	}
}