# 📚 Sistema de Gestión - Biblioteca Digital UNTEC

Aplicación web desarrollada en **Java EE** bajo la arquitectura **MVC (Modelo-Vista-Controlador)** y el patrón de diseño **DAO (Data Access Object)**.

El sistema permite administrar integralmente un catálogo de libros y un registro de usuarios mediante un **CRUD completo**, incorporando una interfaz web basada en Bootstrap, gestión de préstamos bibliotecarios, cálculo automático de plazos y multas, además de soporte para múltiples usuarios concurrentes mediante el modelo multihilo administrado por Apache Tomcat.

---

## 🚀 Características Principales

* 🔐 Autenticación de usuarios mediante sesión.
* 📚 Gestión completa del catálogo de libros.
* 👤 Gestión completa de usuarios.
* 🔄 Operaciones CRUD:

  * Crear
  * Consultar
  * Actualizar
  * Eliminar
* 🔎 Búsqueda de libros por título, autor o ISBN.
* 📖 Gestión de préstamos bibliotecarios.
* 📅 Cálculo automático de fecha de devolución a **14 días**.
* ↩️ Gestión de devoluciones.
* 💰 Cálculo automático de multas por retraso.
* 🔓 Liberación automática del libro después de una devolución.
* 🖥️ Interfaz web responsive mediante Bootstrap 5.
* 🎨 Bootstrap Icons para acciones e interfaz gráfica.
* 🧵 Soporte para múltiples solicitudes concurrentes mediante el **Thread Pool de Apache Tomcat**.
* 🗄️ Persistencia mediante JDBC y MySQL.
* 🏛️ Arquitectura MVC + DAO.
* 🔌 Gestión centralizada de conexión a la base de datos mediante `ConexionDB`.

---

# 🚀 Requisitos del Sistema

Para ejecutar el proyecto se requiere:

| Componente        | Requisito                                        |
| ----------------- | ------------------------------------------------ |
| ☕ Java            | JDK 11 o superior                                |
| 🌐 Servidor       | Apache Tomcat 9.0 o superior                     |
| 🗄️ Base de datos | MySQL Server                                     |
| 💻 IDE            | Eclipse IDE - Enterprise Java and Web Developers |
| 🌐 Navegador      | Chrome, Firefox, Edge u otro navegador moderno   |

---

# 🏛️ Arquitectura del Software

El proyecto implementa una arquitectura en capas orientada a mantener una adecuada **separación de responsabilidades, mantenibilidad y escalabilidad**.

## 1. Patrón MVC

### 📦 Modelo

Paquete:

```text
cl.untec.model
```

Contiene las clases POJO que representan las entidades principales del sistema:

* `Libro`
* `Prestamo`
* `Usuario`

Estas clases representan los datos y entidades utilizadas por la aplicación.

---

### 🖥️ Vista

Ubicación:

```text
src/main/webapp
```

La capa de presentación está desarrollada mediante páginas **JSP**, utilizando:

* JSP
* JSTL
* Bootstrap 5
* Bootstrap Icons
* HTML
* CSS
* JavaScript

Las etiquetas JSTL utilizadas incluyen:

```text
<c:forEach>
<c:if>
<c:choose>
```

Estas permiten generar dinámicamente el contenido de las páginas a partir de los datos proporcionados por el controlador.

---

### 🎮 Controlador

Paquete:

```text
cl.untec.controller
```

Está compuesto principalmente por **Servlets**, responsables de recibir y procesar las peticiones HTTP.

Entre ellos se encuentra:

```text
LoginServlet
```

Los Servlets se encargan de:

* Recibir solicitudes `GET` y `POST`.
* Validar información enviada desde los formularios.
* Gestionar sesiones de usuario.
* Coordinar las operaciones con la capa DAO.
* Redirigir o enviar información hacia las vistas JSP.

---

# 🗄️ Patrón DAO

Paquete:

```text
cl.untec.dao
```

La capa DAO permite separar la lógica de acceso a datos de la lógica de negocio y presentación.

Principales clases:

```text
LibroDAO
PrestamoDAO
UsuarioDAO
```

Estas clases utilizan **JDBC** para comunicarse con MySQL mediante consultas SQL preparadas utilizando:

```java
PreparedStatement
```

Esto permite mantener desacoplada la persistencia respecto del resto de la aplicación.

---

# 🔌 Gestión de Conexión a Base de Datos

Clase:

```text
ConexionDB
```

La clase `ConexionDB` implementa el patrón **Singleton**, centralizando la creación y administración de la conexión utilizada para acceder a la base de datos.

El objetivo es evitar la creación innecesaria de múltiples instancias de configuración de conexión y centralizar el acceso a la base de datos.

---

# 🧵 Concurrencia y Modelo Multihilo

La aplicación se ejecuta sobre **Apache Tomcat**, servidor que utiliza un modelo multihilo para atender múltiples solicitudes HTTP.

El servidor administra un **Thread Pool**, permitiendo procesar solicitudes concurrentes de diferentes usuarios.

Por ejemplo, varios usuarios pueden realizar simultáneamente operaciones como:

* Consultar el catálogo.
* Iniciar sesión.
* Registrar usuarios.
* Consultar libros.
* Solicitar préstamos.
* Procesar devoluciones.

La concurrencia es gestionada por el contenedor web de Tomcat, mientras que la aplicación implementa las operaciones de persistencia mediante JDBC.

---

# 🗄️ Base de Datos

La aplicación utiliza **MySQL** como sistema gestor de base de datos.

Base de datos:

```text
biblioteca_untec
```

## 📐 Modelo Relacional

El sistema está compuesto por las siguientes tablas:

```text
usuarios
    │
    │ 1:N
    ▼
prestamos
    ▲
    │ N:1
    │
libros
```

La tabla `prestamos` relaciona usuarios y libros mediante claves foráneas.

---

# 🛠️ Script de Base de Datos

Ejecute el siguiente script en MySQL para crear la base de datos, tablas y datos iniciales:

```sql
CREATE DATABASE IF NOT EXISTS biblioteca_untec;

USE biblioteca_untec;

-- Tabla de Usuarios del Sistema
CREATE TABLE IF NOT EXISTS usuarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(50) NOT NULL,
    email VARCHAR(50) UNIQUE NOT NULL,
    password VARCHAR(50) NOT NULL
);

-- Tabla de Libros del Catálogo
CREATE TABLE IF NOT EXISTS libros (
    id INT AUTO_INCREMENT PRIMARY KEY,
    titulo VARCHAR(100) NOT NULL,
    autor VARCHAR(100) NOT NULL,
    isbn VARCHAR(20) NOT NULL,
    disponible BOOLEAN DEFAULT TRUE,
    precio DECIMAL(10,2) DEFAULT 15000.00
);

-- Tabla de Préstamos Bibliotecarios
CREATE TABLE IF NOT EXISTS prestamos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    libro_id INT,
    usuario_id INT,
    fecha_prestamo DATE,
    fecha_devolucion_esperada DATE,
    devuelto BOOLEAN DEFAULT FALSE,
    multa DECIMAL(10,2) DEFAULT 0.00,

    FOREIGN KEY (libro_id)
        REFERENCES libros(id)
        ON DELETE CASCADE,

    FOREIGN KEY (usuario_id)
        REFERENCES usuarios(id)
);

-- Usuario administrador inicial
INSERT INTO usuarios (
    nombre,
    email,
    password
) VALUES (
    'Admin UNTEC',
    'admin@untec.cl',
    '1234'
);

-- Libros iniciales
INSERT INTO libros (
    titulo,
    autor,
    isbn,
    disponible,
    precio
) VALUES (
    'Java Programming',
    'James Gosling',
    '978-0134685991',
    TRUE,
    20000.00
);

INSERT INTO libros (
    titulo,
    autor,
    isbn,
    disponible,
    precio
) VALUES (
    'Clean Code',
    'Robert C. Martin',
    '978-0132350884',
    TRUE,
    25000.00
);
```

---

# 📖 Manual de Uso del Sistema

## 🔐 1. Autenticación

Al acceder a la aplicación se mostrará la pantalla de inicio de sesión correspondiente a:

```text
index.jsp
```

Utilice las credenciales de administrador predeterminadas:

**Correo:**

```text
admin@untec.cl
```

**Contraseña:**

```text
1234
```

> ⚠️ Estas credenciales corresponden únicamente a datos de prueba iniciales. En un entorno productivo se recomienda utilizar contraseñas seguras y almacenarlas mediante mecanismos de hash.

---

# 📚 2. Panel de Gestión

Después de iniciar sesión, el usuario accederá al panel principal del sistema.

Vista principal:

```text
libros.jsp
```

Desde este módulo es posible administrar el catálogo y acceder a las funcionalidades principales.

---

## 📚 3. Gestión de Libros

El sistema proporciona un **CRUD completo de libros**.

### Crear

Permite registrar nuevos libros mediante una ventana modal.

Los datos principales incluyen:

* Título.
* Autor.
* ISBN.
* Disponibilidad.
* Precio.

### Consultar

Permite visualizar el catálogo y el estado de disponibilidad de cada libro.

### Buscar

El sistema incorpora una barra de búsqueda que permite localizar libros mediante:

* Título.
* Autor.
* ISBN.

### Editar

El usuario puede modificar la información de un libro utilizando el icono de edición:

```text
✏️
```

### Eliminar

Permite eliminar libros utilizando el icono de papelera:

```text
🗑️
```

---

# 👤 4. Gestión de Usuarios

El sistema permite administrar las cuentas de los usuarios registrados.

Las operaciones disponibles son:

* Crear usuarios.
* Consultar usuarios.
* Editar usuarios.
* Eliminar usuarios.

Cada usuario contiene información como:

* Nombre.
* Correo electrónico.
* Contraseña.

---

# 📖 5. Gestión de Préstamos

El módulo de préstamos permite registrar un préstamo asociando:

```text
Usuario + Libro
```

El sistema verifica que el libro se encuentre disponible antes de realizar el préstamo.

Al registrar un préstamo:

1. Se identifica el usuario.
2. Se selecciona el libro.
3. Se registra la fecha del préstamo.
4. El sistema calcula automáticamente la fecha límite.
5. El libro pasa a estado no disponible.

El plazo estándar definido por el sistema es:

**14 días.**

---

# ↩️ 6. Devoluciones

En la sección de préstamos activos se pueden procesar las devoluciones.

Cuando un usuario devuelve un libro, el sistema:

1. Identifica el préstamo.
2. Obtiene la fecha actual.
3. Compara la fecha actual con la fecha de devolución esperada.
4. Determina si existe retraso.
5. Calcula la multa correspondiente cuando corresponde.
6. Marca el préstamo como devuelto.
7. Libera el libro para nuevos préstamos.

---

# 💰 7. Multas por Retraso

El sistema permite calcular automáticamente una multa cuando el libro es devuelto después de la fecha límite.

La multa queda registrada en la tabla:

```text
prestamos
```

Campo:

```text
multa
```

Si el libro es devuelto dentro del plazo establecido, la multa permanece en:

```text
0.00
```

---

# 🔄 Flujo General del Sistema

```text
                    ┌─────────────────┐
                    │      Usuario    │
                    └────────┬────────┘
                             │
                             ▼
                    ┌─────────────────┐
                    │     JSP / UI    │
                    │  Bootstrap 5    │
                    └────────┬────────┘
                             │
                             ▼
                    ┌─────────────────┐
                    │    Servlet      │
                    │   Controller    │
                    └────────┬────────┘
                             │
                             ▼
                    ┌─────────────────┐
                    │      DAO        │
                    │ JDBC / SQL      │
                    └────────┬────────┘
                             │
                             ▼
                    ┌─────────────────┐
                    │     MySQL       │
                    │ biblioteca_     │
                    │     untec       │
                    └─────────────────┘
```

---

# 📁 Estructura General del Proyecto

La estructura principal del proyecto sigue la separación establecida por MVC y DAO:

```text
BibliotecaUNTEC/
│
├── src/
│   └── main/
│       ├── java/
│       │   └── cl/
│       │       └── untec/
│       │           ├── controller/
│       │           │   └── LoginServlet.java
│       │           │
│       │           ├── dao/
│       │           │   ├── ConexionDB.java
│       │           │   ├── LibroDAO.java
│       │           │   ├── PrestamoDAO.java
│       │           │   └── UsuarioDAO.java
│       │           │
│       │           └── model/
│       │               ├── Libro.java
│       │               ├── Prestamo.java
│       │               └── Usuario.java
│       │
│       └── webapp/
│           ├── META-INF/
│           │   └── MANIFEST.MF
│           │
│           ├── WEB-INF/
│           │
│           ├── index.jsp
│           └── libros.jsp
│
└── README.md
```

> La estructura anterior representa la organización conceptual del proyecto. Los nombres o archivos pueden variar según la configuración final del proyecto Eclipse.

---

# 🛠️ Tecnologías Utilizadas

## Backend

* Java
* Java EE
* Servlets
* JSP
* JSTL
* JDBC
* Apache Tomcat

## Frontend

* HTML5
* CSS3
* JavaScript
* Bootstrap 5
* Bootstrap Icons

## Base de Datos

* MySQL
* SQL

## Arquitectura y Patrones

* MVC
* DAO
* Singleton

## Concurrencia

* Thread Pool administrado por Apache Tomcat

---

# ▶️ Instalación y Ejecución

## 1. Clonar o importar el proyecto

Importar el proyecto en:

```text
Eclipse IDE
```

utilizando la configuración correspondiente para aplicaciones web Java.

---

## 2. Configurar MySQL

Crear la base de datos ejecutando el script SQL incluido en este README.

```text
biblioteca_untec
```

---

## 3. Configurar la conexión

Verificar la configuración de conexión en:

```text
ConexionDB.java
```

Debe configurarse correctamente:

* Host.
* Puerto.
* Usuario.
* Contraseña.
* Nombre de la base de datos.

Ejemplo:

```text
Host: localhost
Puerto: 3306
Base de datos: biblioteca_untec
```

---

## 4. Configurar Apache Tomcat

Agregar Apache Tomcat al entorno de servidores de Eclipse.

Versión recomendada:

```text
Tomcat 9.x
```

---

## 5. Ejecutar la aplicación

Iniciar el servidor Tomcat desde Eclipse y acceder mediante el navegador.

Ejemplo:

```text
http://localhost:8080/BibliotecaDigitalUNTEC/
```

El nombre del contexto puede variar dependiendo del nombre asignado al proyecto en Eclipse.

---

# 🔐 Seguridad

El proyecto utiliza `PreparedStatement` para ejecutar consultas SQL, reduciendo el riesgo de ataques de **SQL Injection** asociados a la construcción directa de consultas mediante concatenación de strings.

> ⚠️ Para un entorno productivo se recomienda implementar adicionalmente:
>
> * Hash seguro de contraseñas.
> * Gestión de secretos mediante variables de entorno.
> * HTTPS.
> * Control de autorización por roles.
> * Validación de entradas.
> * Manejo centralizado de excepciones.
> * Pool de conexiones JDBC.
> * Protección CSRF.
> * Configuración segura de sesiones.

---

# 🧪 Datos de Prueba

## Usuario administrador

```text
Correo: admin@untec.cl
Contraseña: 1234
```

## Libros iniciales

| Libro            | Autor            | ISBN           |  Precio |
| ---------------- | ---------------- | -------------- | ------: |
| Java Programming | James Gosling    | 978-0134685991 | $20.000 |
| Clean Code       | Robert C. Martin | 978-0132350884 | $25.000 |

---

# 🎯 Objetivo Académico

El proyecto tiene como objetivo demostrar la implementación práctica de conceptos fundamentales de desarrollo de aplicaciones web empresariales utilizando Java EE.

Entre los principales conceptos aplicados se encuentran:

* Arquitectura MVC.
* Patrón DAO.
* Patrón Singleton.
* Programación orientada a objetos.
* Servlets.
* JSP.
* JSTL.
* JDBC.
* SQL.
* Bases de datos relacionales.
* CRUD.
* Relaciones mediante claves foráneas.
* Manejo de sesiones.
* Aplicaciones web multicapa.
* Concurrencia y procesamiento multihilo mediante el servidor de aplicaciones.

---

# 👨‍💻 Autor

**Mauricio Fernando Biglia Maldonado**

Proyecto académico:

**Biblioteca Digital UNTEC**

---

# 📄 Licencia

Proyecto desarrollado con fines académicos y educativos.
