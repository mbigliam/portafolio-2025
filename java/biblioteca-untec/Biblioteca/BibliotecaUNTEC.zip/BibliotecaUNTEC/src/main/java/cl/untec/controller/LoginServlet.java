package cl.untec.controller;

import java.io.IOException;
import java.util.List;

import cl.untec.dao.LibroDAO;
import cl.untec.dao.PrestamoDAO;
import cl.untec.dao.UsuarioDAO;
import cl.untec.model.Libro;
import cl.untec.model.Prestamo;
import cl.untec.model.Usuario;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

/**
 * Servlet controlador principal que gestiona las peticiones HTTP (GET y POST)
 * de la aplicación. Actúa como intermediario en el patrón MVC, recibiendo las
 * acciones del usuario, interactuando con las clases DAO y redirigiendo los
 * flujos hacia las vistas JSP correspondientes.
 * 
 * @author UNTEC / Desarrollador
 * @version 1.0
 */
@WebServlet("/login")
public class LoginServlet extends HttpServlet {

	/** Instancia del DAO para operaciones de libros. */
	private LibroDAO libroDAO = new LibroDAO();

	/** Instancia del DAO para operaciones de préstamos. */
	private PrestamoDAO prestamoDAO = new PrestamoDAO();

	/** Instancia del DAO para operaciones de usuarios y autenticación. */
	private UsuarioDAO usuarioDAO = new UsuarioDAO();

	/**
	 * Maneja las peticiones HTTP de tipo GET, procesando acciones de navegación,
	 * cierre de sesión, devoluciones de libros, eliminaciones y consultas del panel
	 * principal.
	 * 
	 * @param request  Objeto HttpServletRequest que contiene la petición del
	 *                 cliente.
	 * @param response Objeto HttpServletResponse para enviar la respuesta.
	 * @throws ServletException Si ocurre un error específico del servlet.
	 * @throws IOException      Si ocurre un error de E/S.
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String accion = request.getParameter("accion");

		// Acción para cerrar la sesión activa del usuario
		if ("logout".equals(accion)) {
			HttpSession session = request.getSession(false);
			if (session != null)
				session.invalidate();
			response.sendRedirect("index.jsp");
			return;
		}

		// Acción para procesar la devolución de un préstamo con multas
		if ("devolver".equals(accion)) {
			int prestamoId = Integer.parseInt(request.getParameter("id"));
			prestamoDAO.devolverPrestamoConMulta(prestamoId);
			response.sendRedirect("login");
			return;
		}

		// Acción para eliminar un libro del catálogo
		if ("eliminarLibro".equals(accion)) {
			int id = Integer.parseInt(request.getParameter("id"));
			libroDAO.eliminarLibro(id);
			response.sendRedirect("login");
			return;
		}

		// Acción para eliminar un usuario del sistema
		if ("eliminarUsuario".equals(accion)) {
			int id = Integer.parseInt(request.getParameter("id"));
			usuarioDAO.eliminarUsuario(id);
			response.sendRedirect("login");
			return;
		}

		// Acción para buscar libros mediante filtros
		if ("buscar".equals(accion)) {
			String query = request.getParameter("query");
			List<Libro> listaLibros = libroDAO.buscarLibros(query);
			List<Prestamo> listaPrestamos = prestamoDAO.obtenerPrestamos();
			List<Usuario> listaUsuarios = usuarioDAO.obtenerUsuarios();

			request.setAttribute("listaLibros", listaLibros);
			request.setAttribute("listaPrestamos", listaPrestamos);
			request.setAttribute("listaUsuarios", listaUsuarios);
			request.getRequestDispatcher("libros.jsp").forward(request, response);
			return;
		}

		// Validación de seguridad: Verifica que exista una sesión activa
		HttpSession session = request.getSession(false);
		if (session == null || session.getAttribute("usuarioLogueado") == null) {
			response.sendRedirect("index.jsp");
			return;
		}

		// Carga general de datos para el panel de administración
		List<Libro> listaLibros = libroDAO.obtenerLibros();
		List<Prestamo> listaPrestamos = prestamoDAO.obtenerPrestamos();
		List<Usuario> listaUsuarios = usuarioDAO.obtenerUsuarios();

		request.setAttribute("listaLibros", listaLibros);
		request.setAttribute("listaPrestamos", listaPrestamos);
		request.setAttribute("listaUsuarios", listaUsuarios);

		request.getRequestDispatcher("libros.jsp").forward(request, response);
	}

	/**
	 * Maneja las peticiones HTTP de tipo POST, procesando formularios de inicio de
	 * sesión y acciones de creación (nuevos libros, nuevos usuarios y nuevos
	 * préstamos).
	 * 
	 * @param request  Objeto HttpServletRequest con los datos enviados por el
	 *                 formulario.
	 * @param response Objeto HttpServletResponse para redireccionar o responder.
	 * @throws ServletException Si ocurre un error específico del servlet.
	 * @throws IOException      Si ocurre un error de E/S.
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String accion = request.getParameter("accion");

		// Registro de un nuevo libro
		if ("crearLibro".equals(accion)) {
			String titulo = request.getParameter("titulo");
			String autor = request.getParameter("autor");
			String isbn = request.getParameter("isbn");
			double precio = Double.parseDouble(request.getParameter("precio"));
			libroDAO.insertarLibro(titulo, autor, isbn, precio);
			response.sendRedirect("login");
			return;
		}

		// Registro de un nuevo usuario
		if ("crearUsuario".equals(accion)) {
			String nombre = request.getParameter("nombre");
			String email = request.getParameter("email");
			String password = request.getParameter("password");
			usuarioDAO.insertarUsuario(nombre, email, password);
			response.sendRedirect("login");
			return;
		}

		// Registro de un nuevo préstamo de libro
		if ("crearPrestamo".equals(accion)) {
			int libroId = Integer.parseInt(request.getParameter("libroId"));
			int usuarioId = Integer.parseInt(request.getParameter("usuarioId"));
			prestamoDAO.registrarPrestamo(libroId, usuarioId);
			response.sendRedirect("login");
			return;
		}

		// Actualizar un libro existente
		if ("actualizarLibro".equals(accion)) {
			int id = Integer.parseInt(request.getParameter("id"));
			String titulo = request.getParameter("titulo");
			String autor = request.getParameter("autor");
			String isbn = request.getParameter("isbn");
			double precio = Double.parseDouble(request.getParameter("precio"));
			libroDAO.actualizarLibro(id, titulo, autor, isbn, precio);
			response.sendRedirect("login");
			return;
		}

		// Actualizar un usuario existente
		if ("actualizarUsuario".equals(accion)) {
			int id = Integer.parseInt(request.getParameter("id"));
			String nombre = request.getParameter("nombre");
			String email = request.getParameter("email");
			String password = request.getParameter("password");
			usuarioDAO.actualizarUsuario(id, nombre, email, password);
			response.sendRedirect("login");
			return;
		}
		// Validación del formulario tradicional de inicio de sesión (Login)
		String email = request.getParameter("email");
		String password = request.getParameter("password");

		if (usuarioDAO.validarLogin(email, password)) {
			String nombreUsuario = usuarioDAO.obtenerNombrePorEmail(email);
			HttpSession session = request.getSession();
			session.setAttribute("usuarioLogueado", nombreUsuario);
			response.sendRedirect("login");
		} else {
			response.sendRedirect("index.jsp?error=1");
		}

	}
}