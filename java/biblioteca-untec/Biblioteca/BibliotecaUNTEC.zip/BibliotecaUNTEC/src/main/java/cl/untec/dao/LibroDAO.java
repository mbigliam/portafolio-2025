package cl.untec.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import cl.untec.model.Libro;

/**
 * Clase Data Access Object (DAO) para la gestión y persistencia de la entidad
 * Libro. Proporciona los métodos necesarios para consultar, buscar, registrar,
 * actualizar y eliminar registros de libros en la base de datos MySQL mediante
 * JDBC.
 * 
 * @author UNTEC / Desarrollador
 * @version 1.0
 */
public class LibroDAO {

	/**
	 * Obtiene el catálogo completo de todos los libros almacenados en el sistema.
	 * 
	 * @return Una lista ({@link List}) de objetos {@link Libro} con su información
	 *         detallada.
	 */
	public List<Libro> obtenerLibros() {
		List<Libro> lista = new ArrayList<>();
		String sql = "SELECT * FROM libros";
		try (Connection conn = ConexionDB.getInstance().getConnection();
				Statement stmt = conn.createStatement();
				ResultSet rs = stmt.executeQuery(sql)) {
			while (rs.next()) {
				Libro l = new Libro();
				l.setId(rs.getInt("id"));
				l.setTitulo(rs.getString("titulo"));
				l.setAutor(rs.getString("autor"));
				l.setIsbn(rs.getString("isbn"));
				l.setDisponible(rs.getBoolean("disponible"));
				l.setPrecio(rs.getDouble("precio"));
				lista.add(l);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return lista;
	}

	/**
	 * Realiza una búsqueda avanzada de libros filtrando por coincidencia parcial en
	 * el título, autor o código ISBN.
	 * 
	 * @param busqueda Texto o palabra clave ingresada por el usuario en el
	 *                 buscador.
	 * @return Una lista ({@link List}) de objetos {@link Libro} que coinciden con
	 *         el filtro de búsqueda.
	 */
	public List<Libro> buscarLibros(String busqueda) {
		List<Libro> lista = new ArrayList<>();
		String sql = "SELECT * FROM libros WHERE titulo LIKE ? OR autor LIKE ? OR isbn LIKE ?";
		try (Connection conn = ConexionDB.getInstance().getConnection();
				PreparedStatement ps = conn.prepareStatement(sql)) {
			String filtro = "%" + busqueda + "%";
			ps.setString(1, filtro);
			ps.setString(2, filtro);
			ps.setString(3, filtro);
			try (ResultSet rs = ps.executeQuery()) {
				while (rs.next()) {
					Libro l = new Libro();
					l.setId(rs.getInt("id"));
					l.setTitulo(rs.getString("titulo"));
					l.setAutor(rs.getString("autor"));
					l.setIsbn(rs.getString("isbn"));
					l.setDisponible(rs.getBoolean("disponible"));
					l.setPrecio(rs.getDouble("precio"));
					lista.add(l);
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return lista;
	}

	/**
	 * Inserta un nuevo registro de libro en la base de datos con estado inicial
	 * disponible.
	 * 
	 * @param titulo Título de la obra literaria.
	 * @param autor  Nombre del autor o creador del libro.
	 * @param isbn   Código internacional normalizado (ISBN).
	 * @param precio Valor monetario de referencia del libro (utilizado para multas
	 *               o extravíos).
	 */
	public void insertarLibro(String titulo, String autor, String isbn, double precio) {
		String sql = "INSERT INTO libros (titulo, autor, isbn, disponible, precio) VALUES (?, ?, ?, true, ?)";
		try (Connection conn = ConexionDB.getInstance().getConnection();
				PreparedStatement ps = conn.prepareStatement(sql)) {
			ps.setString(1, titulo);
			ps.setString(2, autor);
			ps.setString(3, isbn);
			ps.setDouble(4, precio);
			ps.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	/**
	 * Actualiza los datos principales y el precio de un libro existente en el
	 * sistema.
	 * 
	 * @param id     Identificador único del libro a modificar.
	 * @param titulo Nuevo título de la obra.
	 * @param autor  Nuevo autor o creador.
	 * @param isbn   Nuevo código ISBN.
	 * @param precio Nuevo valor monetario referencial.
	 */
	public void actualizarLibro(int id, String titulo, String autor, String isbn, double precio) {
		String sql = "UPDATE libros SET titulo = ?, autor = ?, isbn = ?, precio = ? WHERE id = ?";
		try (Connection conn = ConexionDB.getInstance().getConnection();
				PreparedStatement ps = conn.prepareStatement(sql)) {
			ps.setString(1, titulo);
			ps.setString(2, autor);
			ps.setString(3, isbn);
			ps.setDouble(4, precio);
			ps.setInt(5, id);
			ps.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	/**
	 * Elimina de forma permanente un libro del sistema basándose en su ID único.
	 * 
	 * @param id Identificador numérico del libro que se desea eliminar.
	 */
	public void eliminarLibro(int id) {
		String sql = "DELETE FROM libros WHERE id = ?";
		try (Connection conn = ConexionDB.getInstance().getConnection();
				PreparedStatement ps = conn.prepareStatement(sql)) {
			ps.setInt(1, id);
			ps.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

}