package cl.untec.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import cl.untec.model.Prestamo;

/**
 * Clase Data Access Object (DAO) para la administración y control de los
 * préstamos bibliotecarios. Gestiona el registro de nuevos préstamos con un
 * plazo automático de 14 días, la consulta ordenada de préstamos activos e
 * históricos, y el procesamiento de devoluciones con cálculo de multas.
 * 
 * @author UNTEC / Desarrollador
 * @version 1.0
 */
public class PrestamoDAO {

	/**
	 * Obtiene la lista completa de todos los préstamos registrados en el sistema,
	 * realizando una unión (JOIN) con las tablas de libros y usuarios. Los
	 * registros se ordenan mostrando primero los préstamos activos (no devueltos) y
	 * luego de forma descendente por la fecha de préstamo.
	 * 
	 * @return Una lista ({@link List}) de objetos {@link Prestamo} con la
	 *         información cruzada.
	 */
	public List<Prestamo> obtenerPrestamos() {
		List<Prestamo> lista = new ArrayList<>();
		String sql = "SELECT p.id, l.titulo, u.nombre, p.fecha_prestamo, p.fecha_devolucion_esperada, p.devuelto, p.multa "
				+ "FROM prestamos p JOIN libros l ON p.libro_id = l.id JOIN usuarios u ON p.usuario_id = u.id "
				+ "ORDER BY p.devuelto ASC, p.fecha_prestamo DESC";
		try (Connection conn = ConexionDB.getInstance().getConnection();
				Statement stmt = conn.createStatement();
				ResultSet rs = stmt.executeQuery(sql)) {
			while (rs.next()) {
				Prestamo p = new Prestamo();
				p.setId(rs.getInt("id"));
				p.setTituloLibro(rs.getString("titulo"));
				p.setNombreUsuario(rs.getString("nombre"));
				p.setFechaPrestamo(rs.getDate("fecha_prestamo"));
				p.setFechaDevolucionEsperada(rs.getDate("fecha_devolucion_esperada"));
				p.setDevuelto(rs.getBoolean("devuelto"));
				p.setMulta(rs.getDouble("multa"));
				lista.add(p);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return lista;
	}

	/**
	 * Registra un nuevo préstamo en el sistema asignando la fecha actual y
	 * calculando automáticamente una fecha límite de devolución de 14 días.
	 * Asimismo, actualiza el estado del libro correspondiente a no disponible
	 * (falso).
	 * 
	 * @param libroId   Identificador único del libro que se va a prestar.
	 * @param usuarioId Identificador único del usuario que solicita el préstamo.
	 */
	public void registrarPrestamo(int libroId, int usuarioId) {
		String sqlPrestamo = "INSERT INTO prestamos (libro_id, usuario_id, fecha_prestamo, fecha_devolucion_esperada, devuelto) "
				+ "VALUES (?, ?, CURDATE(), DATE_ADD(CURDATE(), INTERVAL 14 DAY), false)";
		String sqlLibro = "UPDATE libros SET disponible = false WHERE id = ?";
		try (Connection conn = ConexionDB.getInstance().getConnection();
				PreparedStatement ps1 = conn.prepareStatement(sqlPrestamo);
				PreparedStatement ps2 = conn.prepareStatement(sqlLibro)) {
			ps1.setInt(1, libroId);
			ps1.setInt(2, usuarioId);
			ps1.executeUpdate();
			ps2.setInt(1, libroId);
			ps2.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	/**
	 * Procesa la devolución de un libro prestado evaluando si la fecha actual
	 * excede la fecha límite esperada. En caso de retraso, asigna automáticamente
	 * una multa monetaria. Además, libera el libro actualizando su estado de
	 * disponibilidad a verdadero.
	 * 
	 * @param prestamoId Identificador único del registro de préstamo que se va a
	 *                   finalizar.
	 */
	public void devolverPrestamoConMulta(int prestamoId) {
		String sqlCheck = "SELECT p.fecha_devolucion_esperada, l.precio FROM prestamos p "
				+ "JOIN libros l ON p.libro_id = l.id WHERE p.id = ?";
		double multaCalculada = 0.0;

		try (Connection conn = ConexionDB.getInstance().getConnection();
				PreparedStatement psCheck = conn.prepareStatement(sqlCheck)) {
			psCheck.setInt(1, prestamoId);
			try (ResultSet rs = psCheck.executeQuery()) {
				if (rs.next()) {
					Date fechaEsperada = rs.getDate("fecha_devolucion_esperada");
					if (fechaEsperada != null) {
						java.sql.Date fechaActual = new java.sql.Date(System.currentTimeMillis());
						if (fechaActual.after(fechaEsperada)) {
							multaCalculada = 1000.0; // Multa fija por retraso
						}
					}
				}
			}

			String sqlUpdatePrestamo = "UPDATE prestamos SET devuelto = true, multa = ? WHERE id = ?";
			String sqlUpdateLibro = "UPDATE libros SET disponible = true WHERE id = (SELECT libro_id FROM prestamos WHERE id = ?)";
			try (PreparedStatement ps1 = conn.prepareStatement(sqlUpdatePrestamo);
					PreparedStatement ps2 = conn.prepareStatement(sqlUpdateLibro)) {
				ps1.setDouble(1, multaCalculada);
				ps1.setInt(2, prestamoId);
				ps1.executeUpdate();
				ps2.setInt(1, prestamoId);
				ps2.executeUpdate();
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}