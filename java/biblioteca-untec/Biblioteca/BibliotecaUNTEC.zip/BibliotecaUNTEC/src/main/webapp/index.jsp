<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Login - Biblioteca Digital UNTEC</title>
    <!-- Bootstrap 5 CSS para diseño responsivo y moderno -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap Icons para iconografía corporativa -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
</head>
<body class="bg-light d-flex align-items-center py-4" style="height: 100vh;">
    
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-5">
                <!-- Tarjeta contenedora con bordes redondeados y sombra suave -->
                <div class="card shadow border-0 rounded-4">
                    <div class="card-body p-5">
                        
                        <!-- Encabezado de la Vista / Login -->
                        <div class="text-center mb-4">
                            <i class="bi bi-book-half text-primary fs-1"></i>
                            <h3 class="fw-bold mt-2">Biblioteca UNTEC</h3>
                            <p class="text-muted small">Sistema de Gestión Digital</p>
                        </div>

                        <!-- Alerta condicional en caso de error de autenticación -->
                        <c:if test="${param.error == '1'}">
                            <div class="alert alert-danger alert-dismissible fade show small" role="alert">
                                <i class="bi bi-exclamation-triangle-fill me-1"></i> Correo o contraseña incorrectos.
                                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                            </div>
                        </c:if>

                        <!-- Formulario de Autenticación -->
                        <form action="login" method="POST">
                            <div class="mb-3">
                                <label class="form-label text-secondary small fw-bold">Correo Electrónico</label>
                                <div class="input-group">
                                    <span class="input-group-text bg-light"><i class="bi bi-envelope"></i></span>
                                    <input type="email" name="email" class="form-control" placeholder="admin@untec.cl" required>
                                </div>
                            </div>
                            
                            <div class="mb-4">
                                <label class="form-label text-secondary small fw-bold">Contraseña</label>
                                <div class="input-group">
                                    <span class="input-group-text bg-light"><i class="bi bi-lock"></i></span>
                                    <input type="password" name="password" class="form-control" placeholder="••••••••" required>
                                </div>
                            </div>
                            
                            <button type="submit" class="btn btn-primary w-100 py-2 fw-bold shadow-sm">
                                <i class="bi bi-box-arrow-in-right me-1"></i> Ingresar al Sistema
                            </button>
                        </form>

                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap 5 JS Bundle -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>