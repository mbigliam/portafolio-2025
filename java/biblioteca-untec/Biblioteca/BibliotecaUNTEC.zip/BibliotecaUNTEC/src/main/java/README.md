# Sistema de Gestión - Biblioteca Digital UNTEC

Aplicación web desarrollada en Java EE bajo la arquitectura **MVC (Modelo-Vista-Controlador)** y el patrón de diseño **DAO** (Data Access Object). El sistema permite administrar integralmente un catálogo de libros y un registro de usuarios mediante un CRUD completo con iconos interactivos, además de gestionar préstamos bibliotecarios con plazos automáticos de 14 días, multas por retraso y control de concurrencia mediante multihilos (*Thread Pool* del servidor Tomcat).

---

## 🚀 Requisitos del Sistema
* **Java Development Kit (JDK):** Versión 11 o superior.
* **Servidor de Aplicaciones:** Apache Tomcat v9.0 o superior.
* **Gestor de Base de Datos:** MySQL Server.
* **IDE de Desarrollo:** Eclipse IDE (Enterprise Java and Web Developers).

---

## 🏛️ Arquitectura del Software y Patrones de Diseño
El proyecto implementa una arquitectura en capas desacoplada para garantizar la escalabilidad, la mantenibilidad y la separación de responsabilidades:

1. **Patrón MVC (Modelo-Vista-Controlador):**
   * **Modelo (`cl.untec.model`):** Clases POJO que representan las entidades de negocio (`Libro`, `Prestamo`, `Usuario`).
   * **Vista (`src/main/webapp`):** Páginas JSP dinámicas estructuradas con **Bootstrap 5**, Bootstrap Icons y etiquetas JSTL (`c:forEach`, `c:if`, `c:choose`) para la renderización de la interfaz gráfica.
   * **Controlador (`cl.untec.controller`):** Servlets principales (`LoginServlet`) que interceptan las peticiones HTTP (GET y POST), gestionan las sesiones de usuario y coordinan la lógica con la capa de datos.

2. **Patrón DAO y Concurrencia:**
   * **Capa DAO (`cl.untec.dao`):** Clases de persistencia desacopladas (`LibroDAO`, `PrestamoDAO`, `UsuarioDAO`) que ejecutan consultas SQL preparadas (*PreparedStatement*) mediante la API JDBC.
   * **Patrón Singleton (`ConexionDB`):** Garantiza una única instancia de conexión compartida hacia la base de datos para optimizar los recursos del servidor.
   * **Modelo Multihilo:** Gestionado de forma nativa por el servidor Apache Tomcat a través de un *Thread Pool*, permitiendo que múltiples usuarios consulten catálogos, inicien sesión y realicen préstamos concurrentemente de manera segura.

---

## 🗄️ Esquema y Script de la Base de Datos
Ejecute el siguiente script SQL en su gestor MySQL para configurar la base de datos y sus tablas relacionales:

```sql
CREATE DATABASE IF NOT EXISTS biblioteca_untec;
USE biblioteca_untec;

-- Tabla de Usuarios del Sistema
CREATE TABLE IF NOT EXISTS usuarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(50) NOT NULL,
    email VARCHAR(50) UNIQUE NOT NULL,
    password VARCHAR(50) NOT NULL
);

-- Tabla de Libros del Catálogo
CREATE TABLE IF NOT EXISTS libros (
    id INT AUTO_INCREMENT PRIMARY KEY,
    titulo VARCHAR(100) NOT NULL,
    autor VARCHAR(100) NOT NULL,
    isbn VARCHAR(20) NOT NULL,
    disponible BOOLEAN DEFAULT TRUE,
    precio DECIMAL(10,2) DEFAULT 15000.00
);

-- Tabla de Préstamos Bibliotecarios
CREATE TABLE IF NOT EXISTS prestamos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    libro_id INT,
    usuario_id INT,
    fecha_prestamo DATE,
    fecha_devolucion_esperada DATE,
    devuelto BOOLEAN DEFAULT FALSE,
    multa DECIMAL(10,2) DEFAULT 0.00,
    FOREIGN KEY (libro_id) REFERENCES libros(id) ON DELETE CASCADE,
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id)
);

-- Datos de Prueba Iniciales
INSERT INTO usuarios (nombre, email, password) VALUES ('Admin UNTEC', 'admin@untec.cl', '1234');
INSERT INTO libros (titulo, autor, isbn, disponible, precio) VALUES ('Java Programming', 'James Gosling', '978-0134685991', true, 20000.00);
INSERT INTO libros (titulo, autor, isbn, disponible, precio) VALUES ('Clean Code', 'Robert C. Martin', '978-0132350884', true, 25000.00);

## 🗄️ MANUAL DE USO DE SISTEMA

Autenticación (Vista index.jsp):

Al acceder a la aplicación, ingrese con las credenciales de administrador predeterminadas:

Correo: admin@untec.cl

Contraseña: 1234

Panel de Gestión y Control (Vista libros.jsp):

Catálogo de Libros (CRUD Completo): Permite visualizar la disponibilidad en tiempo real, registrar nuevos títulos mediante ventana modal, editarlos con el icono de lápiz (📋✏️) o eliminarlos con el icono de papelera (🗑️). Cuenta además con una barra de búsqueda avanzada por título, autor o ISBN.

Gestión de Usuarios: Permite administrar las cuentas de los lectores registrados, dar de alta nuevos usuarios, editar sus perfiles o eliminarlos del sistema.

Módulo de Préstamos: Permite emitir préstamos vinculando un libro disponible y un usuario registrado. El sistema calcula automáticamente un plazo límite de 14 días.

Devoluciones y Multas: En la sección de Préstamos Activos, al procesar una devolución, el sistema valida la fecha actual; si se supera el plazo límite, calcula y asigna una multa monetaria de forma automática, liberando el libro inmediatamente para nuevos préstamos.

¡Copia y pega este bloque final en tu archivo `README.md` y tendrás un documento de entrega sobresaliente!