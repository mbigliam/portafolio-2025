package cl.untec.model;

/**
 * Clase modelo (POJO) que representa la entidad Libro dentro del sistema de la
 * biblioteca. Almacena las propiedades físicas y de estado de un libro, así
 * como su valor comercial de referencia para el cálculo de multas o extravíos.
 * 
 * @author UNTEC / Desarrollador
 * @version 1.0
 */
public class Libro {

	/** Identificador único del libro en la base de datos. */
	private int id;

	/** Título de la obra literaria. */
	private String titulo;

	/** Autor o creador del libro. */
	private String autor;

	/** Código internacional normalizado del libro (ISBN). */
	private String isbn;

	/**
	 * Estado de disponibilidad del libro (`true` si está libre para préstamo,
	 * `false` si se encuentra prestado).
	 */
	private boolean disponible;

	/** Precio referencial del libro. */
	private double precio;

	/**
	 * Obtiene el ID único del libro.
	 * 
	 * @return Valor entero con el identificador del libro.
	 */
	public int getId() {
		return id;
	}

	/**
	 * Establece el ID único del libro.
	 * 
	 * @param id Nuevo identificador numérico.
	 */
	public void setId(int id) {
		this.id = id;
	}

	/**
	 * Obtiene el título del libro.
	 * 
	 * @return Cadena ({@link String}) con el título de la obra.
	 */
	public String getTitulo() {
		return titulo;
	}

	/**
	 * Establece el título del libro.
	 * 
	 * @param titulo Nuevo título para la obra.
	 */
	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}

	/**
	 * Obtiene el nombre del autor del libro.
	 * 
	 * @return Cadena ({@link String}) con el autor.
	 */
	public String getAutor() {
		return autor;
	}

	/**
	 * Establece el nombre del autor del libro.
	 * 
	 * @param autor Nuevo autor o creador.
	 */
	public void setAutor(String autor) {
		this.autor = autor;
	}

	/**
	 * Obtiene el código ISBN del libro.
	 * 
	 * @return Cadena ({@link String}) con el ISBN.
	 */
	public String getIsbn() {
		return isbn;
	}

	/**
	 * Establece el código ISBN del libro.
	 * 
	 * @param isbn Nuevo código ISBN.
	 */
	public void setIsbn(String isbn) {
		this.isbn = isbn;
	}

	/**
	 * Verifica si el libro se encuentra disponible para préstamo.
	 * 
	 * @return `true` si está disponible, `false` en caso contrario.
	 */
	public boolean isDisponible() {
		return disponible;
	}

	/**
	 * Modifica el estado de disponibilidad del libro.
	 * 
	 * @param disponible Nuevo estado booleano de disponibilidad.
	 */
	public void setDisponible(boolean disponible) {
		this.disponible = disponible;
	}

	/**
	 * Obtiene el precio referencial del libro.
	 * 
	 * @return Valor de tipo `double` correspondiente al precio.
	 */
	public double getPrecio() {
		return precio;
	}

	/**
	 * Establece el precio referencial del libro.
	 * 
	 * @param precio Nuevo valor comercial de referencia.
	 */
	public void setPrecio(double precio) {
		this.precio = precio;
	}
}