package cl.untec.model;

import java.sql.Date;

/**
 * Clase modelo (POJO) que representa la entidad Prestamo dentro del sistema de
 * la biblioteca. Almacena la relación entre libros y usuarios, las fechas de
 * control (préstamo y límite esperada), el estado de devolución, las multas
 * aplicadas por retraso y atributos auxiliares para la vista.
 * 
 * @author UNTEC / Desarrollador
 * @version 1.0
 */
public class Prestamo {

	/** Identificador único del registro de préstamo. */
	private int id;

	/** Identificador del libro asociado al préstamo. */
	private int libroId;

	/** Identificador del usuario que realizó el préstamo. */
	private int usuarioId;

	/** Fecha en la que se efectuó el préstamo del libro. */
	private Date fechaPrestamo;

	/**
	 * Fecha límite esperada para la devolución del libro (plazo por defecto de 14
	 * días).
	 */
	private Date fechaDevolucionEsperada;

	/**
	 * Estado de devolución del préstamo (`true` si ya fue devuelto, `false` si se
	 * encuentra activo/vigente).
	 */
	private boolean devuelto;

	/** Monto de la multa acumulada por retraso en la devolución. */
	private double multa;

	// Atributos auxiliares para la vista
	/**
	 * Título del libro (atributo auxiliar para mostrar directamente en las tablas
	 * de la interfaz).
	 */
	private String tituloLibro;

	/**
	 * Nombre del usuario (atributo auxiliar para mostrar directamente en las tablas
	 * de la interfaz).
	 */
	private String nombreUsuario;

	/**
	 * Obtiene el ID único del préstamo.
	 * 
	 * @return Valor entero con el identificador del préstamo.
	 */
	public int getId() {
		return id;
	}

	/**
	 * Establece el ID único del préstamo.
	 * 
	 * @param id Nuevo identificador numérico.
	 */
	public void setId(int id) {
		this.id = id;
	}

	/**
	 * Obtiene el ID del libro asociado al préstamo.
	 * 
	 * @return Identificador del libro.
	 */
	public int getLibroId() {
		return libroId;
	}

	/**
	 * Establece el ID del libro asociado al préstamo.
	 * 
	 * @param libroId Identificador del libro.
	 */
	public void setLibroId(int libroId) {
		this.libroId = libroId;
	}

	/**
	 * Obtiene el ID del usuario que solicitó el préstamo.
	 * 
	 * @return Identificador del usuario.
	 */
	public int getUsuarioId() {
		return usuarioId;
	}

	/**
	 * Establece el ID del usuario que solicitó el préstamo.
	 * 
	 * @param usuarioId Identificador del usuario.
	 */
	public void setUsuarioId(int usuarioId) {
		this.usuarioId = usuarioId;
	}

	/**
	 * Obtiene la fecha en que se realizó el préstamo.
	 * 
	 * @return Objeto {@link Date} con la fecha de préstamo.
	 */
	public Date getFechaPrestamo() {
		return fechaPrestamo;
	}

	/**
	 * Establece la fecha en que se realizó el préstamo.
	 * 
	 * @param fechaPrestamo Nueva fecha de préstamo.
	 */
	public void setFechaPrestamo(Date fechaPrestamo) {
		this.fechaPrestamo = fechaPrestamo;
	}

	/**
	 * Obtiene la fecha límite esperada de devolución.
	 * 
	 * @return Objeto {@link Date} con la fecha límite.
	 */
	public Date getFechaDevolucionEsperada() {
		return fechaDevolucionEsperada;
	}

	/**
	 * Establece la fecha límite esperada de devolución.
	 * 
	 * @param fechaDevolucionEsperada Nueva fecha límite.
	 */
	public void setFechaDevolucionEsperada(Date fechaDevolucionEsperada) {
		this.fechaDevolucionEsperada = fechaDevolucionEsperada;
	}

	/**
	 * Verifica si el préstamo ya fue devuelto.
	 * 
	 * @return `true` si el libro fue devuelto, `false` si el préstamo sigue
	 *         vigente.
	 */
	public boolean isDevuelto() {
		return devuelto;
	}

	/**
	 * Modifica el estado de devolución del préstamo.
	 * 
	 * @param devuelto Nuevo estado booleano de devolución.
	 */
	public void setDevuelto(boolean devuelto) {
		this.devuelto = devuelto;
	}

	/**
	 * Obtiene el monto de la multa calculada por retraso.
	 * 
	 * @return Valor de tipo `double` con la multa.
	 */
	public double getMulta() {
		return multa;
	}

	/**
	 * Establece el monto de la multa por retraso.
	 * 
	 * @param multa Nuevo valor monetario de la multa.
	 */
	public void setMulta(double multa) {
		this.multa = multa;
	}

	/**
	 * Obtiene el título auxiliar del libro para la vista.
	 * 
	 * @return Cadena ({@link String}) con el título del libro.
	 */
	public String getTituloLibro() {
		return tituloLibro;
	}

	/**
	 * Establece el título auxiliar del libro para la vista.
	 * 
	 * @param tituloLibro Título del libro correspondiente.
	 */
	public void setTituloLibro(String tituloLibro) {
		this.tituloLibro = tituloLibro;
	}

	/**
	 * Obtiene el nombre auxiliar del usuario para la vista.
	 * 
	 * @return Cadena ({@link String}) con el nombre del usuario.
	 */
	public String getNombreUsuario() {
		return nombreUsuario;
	}

	/**
	 * Establece el nombre auxiliar del usuario para la vista.
	 * 
	 * @param nombreUsuario Nombre del usuario correspondiente.
	 */
	public void setNombreUsuario(String nombreUsuario) {
		this.nombreUsuario = nombreUsuario;
	}
}